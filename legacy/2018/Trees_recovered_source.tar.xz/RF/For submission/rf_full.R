# Initializing parameters
##############################################################################

# Package for ML techniques

library(kknn)
library(randomForest)

# Package for R compiling

library(compiler)
enableJIT(3)

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Input features set

inputs=list(c("Depth_m","qt_MPa","fs_kPa","u_kPa"))
inputs=append(inputs,list(c("Depth_m","Qt1","Fr_p","Bq")))
inputs=append(inputs,list(c("Depth_m","Qtn","Fr_p","U2")))

# Outputs

outputs=c("SBTn","MSBTn")

# Initializing matrix with "k" values obtained for each testing case and its accuracy associated

kval=matrix(0,10,2)
colnames(kval)=c("k","accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(kval)=rn

# Initializing list with kval matrices

lokval=list()

# Initializing list with kval mean

lokvalm=list()

# Initializing list with kval standard deviation

lokvalsd=list()

# Initializing list with kval matrices

lokvalk=list()

# Initializing list with kval mean

lokvalkm=list()

# Initializing list with kval standard deviation

lokvalksd=list()

# Initializing list of importances

loimp=list()

# Initializing list of mean importances

loimpm=list()

# Initializing list of confusion matrices

loconf=list()

# Initializing list of mean confusion matrices

loconfm=list()

# k-NN mode for filtering

mode="rectangular"

# Choose if the FSB class 0 has to be removed

czrem=0

# Random forest application
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Removing Robertson's (2016) class 0
      
      if(out=="MSBTn"&&czrem==1){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Normalization of unbalanced training set
      
      cat("\nUnbalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # Pre-testing the balanced set
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- randomForest(form,data=trainb,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        mpb=mpb+confb[j,j]/sum(confb[,j])
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      
      # Pre-testing the unbalanced set
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        train=trainb
        test=testb
        valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        cat("Using unbalanced set!\n\n")
      }
      
      cat("Testing\n")
      
      # Testing
      
      # Constructing the model
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, test, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,test[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "k" value for the ith testing case
      
      kval[i,1]=500
      
      # Keeping accuracy related to "k"
      
      kval[i,2]=mp*100
      
      # Saving importance vector in a list
      
      loimp[[length(loimp)+1]]=fit$importance
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,2])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,2])
    
    # Best "k"
    
    x=kval[,1]
    z=table(as.vector(x))
    bk=as.numeric(names(z)[z == max(z)])[1]
    lokvalk[[length(lokvalk)+1]]=bk
    
    # Adding mean for the best "k" to the list lokvalkm
    
    lokvalkm[[length(lokvalkm)+1]]=mean(kval[kval[,1]==bk,2])
    
    # Adding standard deviation for the best "k" to the list lokvalksd
    
    lokvalksd[[length(lokvalksd)+1]]=sd(kval[kval[,1]==bk,2])
    
    # Saving importance vector in a list
    
    loimpm[[length(loimpm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpm[[length(loimpm)]])=inp
    for(at in inp){
      for(j in (length(loimp)-9):length(loimp)){
        loimpm[[length(loimpm)]][at,1]=loimpm[[length(loimpm)]][at,1]+loimp[[j]][at,1]
      }
    }
    loimpm[[length(loimpm)]]=loimpm[[length(loimpm)]]/10
  }
}

# Introducing geological age
##############################################################################

# Selected data set

data=dataGeo # Change it inside loop too

# Folds for the selected data set

folds=foldsGeo

# Input features set

inputs=list(c("CG","Depth_m","qt_MPa","fs_kPa","u_kPa"))
inputs=append(inputs,list(c("CG","Depth_m","Qtn","Fr_p","U2")))

# Outputs

outputs=c("MSBTn")

# Random forest application
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataGeo
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Removing Robertson's (2016) class 0
      
      if(out=="MSBTn"&&czrem==1){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Normalization of unbalanced training set
      
      cat("\nUnbalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # Pre-testing the balanced set
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- randomForest(form,data=trainb,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        mpb=mpb+confb[j,j]/sum(confb[,j])
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      
      # Pre-testing the unbalanced set
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        train=trainb
        test=testb
        valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        cat("Using unbalanced set!\n\n")
      }
      
      cat("Testing\n")
      
      # Testing
      
      # Constructing the model
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, test, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,test[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "k" value for the ith testing case
      
      kval[i,1]=500
      
      # Keeping accuracy related to "k"
      
      kval[i,2]=mp*100
      
      # Saving importance vector in a list
      
      loimp[[length(loimp)+1]]=fit$importance
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,2])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,2])
    
    # Best "k"
    
    x=kval[,1]
    z=table(as.vector(x))
    bk=as.numeric(names(z)[z == max(z)])[1]
    lokvalk[[length(lokvalk)+1]]=bk
    
    # Adding mean for the best "k" to the list lokvalkm
    
    lokvalkm[[length(lokvalkm)+1]]=mean(kval[kval[,1]==bk,2])
    
    # Adding standard deviation for the best "k" to the list lokvalksd
    
    lokvalksd[[length(lokvalksd)+1]]=sd(kval[kval[,1]==bk,2])
    
    # Saving importance vector in a list
    
    loimpm[[length(loimpm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpm[[length(loimpm)]])=inp
    for(at in inp){
      for(j in (length(loimp)-9):length(loimp)){
        loimpm[[length(loimpm)]][at,1]=loimpm[[length(loimpm)]][at,1]+loimp[[j]][at,1]
      }
    }
    loimpm[[length(loimpm)]]=loimpm[[length(loimpm)]]/10
  }
}

# Biased inputs
##############################################################################

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Input features set

inputs=list(c("Qtn","Fr_p"))

# Outputs

outputs=c("SBTn")

# Random forest application - Biased combination of 1991
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Removing Robertson's (2016) class 0
      
      if(out=="MSBTn"&&czrem==1){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Normalization of unbalanced training set
      
      cat("\nUnbalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # Pre-testing the balanced set
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- randomForest(form,data=trainb,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        mpb=mpb+confb[j,j]/sum(confb[,j])
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      
      # Pre-testing the unbalanced set
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        train=trainb
        test=testb
        valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        cat("Using unbalanced set!\n\n")
      }
      
      cat("Testing\n")
      
      # Testing
      
      # Constructing the model
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, test, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,test[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "k" value for the ith testing case
      
      kval[i,1]=500
      
      # Keeping accuracy related to "k"
      
      kval[i,2]=mp*100
      
      # Saving importance vector in a list
      
      loimp[[length(loimp)+1]]=fit$importance
      
      # Keeping conf table
      
      loconf[[length(loconf)+1]]=conf
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,2])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,2])
    
    # Best "k"
    
    x=kval[,1]
    z=table(as.vector(x))
    bk=as.numeric(names(z)[z == max(z)])[1]
    lokvalk[[length(lokvalk)+1]]=bk
    
    # Adding mean for the best "k" to the list lokvalkm
    
    lokvalkm[[length(lokvalkm)+1]]=mean(kval[kval[,1]==bk,2])
    
    # Adding standard deviation for the best "k" to the list lokvalksd
    
    lokvalksd[[length(lokvalksd)+1]]=sd(kval[kval[,1]==bk,2])
    
    # Saving importance vector in a list
    
    loimpm[[length(loimpm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpm[[length(loimpm)]])=inp
    for(at in inp){
      for(j in (length(loimp)-9):length(loimp)){
        loimpm[[length(loimpm)]][at,1]=loimpm[[length(loimpm)]][at,1]+loimp[[j]][at,1]
      }
    }
    loimpm[[length(loimpm)]]=loimpm[[length(loimpm)]]/10
    
    loconfm[[length(loconfm)+1]]=loconf[[length(loconf)]]
    
    for(j in 2:10){
      loconfm[[length(loconfm)]]=loconfm[[length(loconfm)]]+loconf[[length(loconf)-j+1]]
    }
    
    loconfm[[length(loconfm)]]=loconfm[[length(loconfm)]]/10
  }
}

# Initializing parameters
##############################################################################

# Input features set

inputs=list(c("Qtn","Fr_p","U2"))

# Outputs

outputs=c("MSBTn")

# Random forest application - Biased combination of 2016
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Removing Robertson's (2016) class 0
      
      if(out=="MSBTn"&&czrem==1){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Normalization of unbalanced training set
      
      cat("\nUnbalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalid)){
          mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtest)){
          mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # Pre-testing the balanced set
      
      # Constructing the model
      
      rownames(trainb)=NULL
      
      fit <- randomForest(form,data=trainb,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, validb, type = "class")
      
      # Calculating accuracy (mean precision)
      
      confb=table(preds,validb[,out])
      
      mpb=0
      
      for(j in colnames(confb)){
        mpb=mpb+confb[j,j]/sum(confb[,j])
      }
      
      mpb=mpb/ncol(confb)
      
      cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      
      # Pre-testing the unbalanced set
      
      # Constructing the model
      
      rownames(train)=NULL
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, valid, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,valid[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      
      if(mpb>mp){
        train=trainb
        test=testb
        valid=validb
        cat("Using balanced set!\n\n")
      }
      else{
        cat("Using unbalanced set!\n\n")
      }
      
      cat("Testing\n")
      
      # Testing
      
      # Constructing the model
      
      fit <- randomForest(form,data=train,ntree=500)
      #plot(fit)
      
      # Predicting
      
      preds <- predict(fit, test, type = "class")
      
      # Calculating accuracy (mean precision)
      
      conf=table(preds,test[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        mp=mp+conf[j,j]/sum(conf[,j])
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "k" value for the ith testing case
      
      kval[i,1]=500
      
      # Keeping accuracy related to "k"
      
      kval[i,2]=mp*100
      
      # Saving importance vector in a list
      
      loimp[[length(loimp)+1]]=fit$importance
      
      # Keeping conf table
      
      loconf[[length(loconf)+1]]=conf
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,2])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,2])
    
    # Best "k"
    
    x=kval[,1]
    z=table(as.vector(x))
    bk=as.numeric(names(z)[z == max(z)])[1]
    lokvalk[[length(lokvalk)+1]]=bk
    
    # Adding mean for the best "k" to the list lokvalkm
    
    lokvalkm[[length(lokvalkm)+1]]=mean(kval[kval[,1]==bk,2])
    
    # Adding standard deviation for the best "k" to the list lokvalksd
    
    lokvalksd[[length(lokvalksd)+1]]=sd(kval[kval[,1]==bk,2])
    
    # Saving importance vector in a list
    
    loimpm[[length(loimpm)+1]]=as.data.frame(matrix(0,length(inp),1))
    rownames(loimpm[[length(loimpm)]])=inp
    for(at in inp){
      for(j in (length(loimp)-9):length(loimp)){
        loimpm[[length(loimpm)]][at,1]=loimpm[[length(loimpm)]][at,1]+loimp[[j]][at,1]
      }
    }
    loimpm[[length(loimpm)]]=loimpm[[length(loimpm)]]/10
    
    # Adding the mean conf table to loconfm
    
    loconfm[[length(loconfm)+1]]=loconf[[length(loconf)]]
    
    for(j in 2:10){
      loconfm[[length(loconfm)]]=loconfm[[length(loconfm)]]+loconf[[length(loconf)-j+1]]
    }
    
    loconfm[[length(loconfm)]]=loconfm[[length(loconfm)]]/10
  }
}